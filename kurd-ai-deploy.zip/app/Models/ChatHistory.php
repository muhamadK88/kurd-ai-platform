<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatHistory extends Model
{
    protected $fillable = ['session_id', 'role', 'content', 'reaction'];

    public function session()
    {
        return $this->belongsTo(ChatSession::class, 'session_id');
    }
}
